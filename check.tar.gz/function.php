<?php
function sc_send(  $text , $desp = '' , $key = 'SCU36340T191cb20be8a0bcb6c51811513d78fee45bf981fd07239'  )
{
	$postdata = http_build_query(
    array(
        'text' => $text,
        'desp' => $desp
    )
);

$opts = array('http' =>
    array(
        'method'  => 'POST',
        'header'  => 'Content-type: application/x-www-form-urlencoded',
        'content' => $postdata
    )
);
$context  = stream_context_create($opts);
return $result = file_get_contents('https://sc.ftqq.com/'.$key.'.send', false, $context);

}
function whSend($msg,$event = 'msg_pusher',$key = 'cynuEZ9MM-TS3rhSZVQ13G')
{
    $headers = array("Content-type: application/json");
    $url = 'https://maker.ifttt.com/trigger/' . $event . '/with/key/' . $key;
    $data = array('value1' => $msg);
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}
function icmping($ip) {
    $status = -1;
    if (strcasecmp(PHP_OS, 'WINNT') === 0) {
        // Windows 服务器下
        $pingresult = exec("ping -n 2 {$ip}", $outcome, $status);
    } elseif (strcasecmp(PHP_OS, 'Linux') === 0) {
        // Linux 服务器下
        $pingresult = exec("ping -c 2 {$ip}", $outcome, $status);
    }
    if (0 == $status) {
        $status = 'true';
    } else {
        $status = 'false';
    }
    return $status;
}
?>