<?php
include 'function.php';
include 'config.php';
error_reporting(0);
date_default_timezone_set('Asia/Chongqing'); 
$date = date('Y-m-d H:i:s:ms');
$t = 0;
$array = array();
while(!empty($ips[$t][0])){
	$temp = icmping($ips[$t][1]);
	$array[$t] = array("node"=>$ips[$t][0],"icmp"=>$temp);
	$t=$t+1;
}
$temp = json_encode($array);
echo $temp;

//	读取文件
$myfile = fopen("data.txt", "r") or die("Unable to open file!");
$data = fread($myfile,filesize("data.txt"));
fclose($myfile);

if($data!=$temp){
	$t = 0;
  	$arr = (array) json_decode($data,true);
	while(!empty($ips[$t][0])){
		if($array[$t]['icmp'] != $arr[$t]['icmp']){
			if($array[$t]['icmp'] == 'true'){
            	whSend('服务器'.$ips[$t][0].'于'.$date.'已恢复正常');
            }else{
            	whSend('服务器'.$ips[$t][0].'于'.$date.'出现异常');
            }
        }
		$t=$t+1;
}
//	写入文件
$myfile = fopen("data.txt", "w") or die("Unable to open file!");
fwrite($myfile,$temp);
fclose($myfile);
}
$myfile = fopen("latest.txt", "w") or die("Unable to open file!");
fwrite($myfile,$date);
fclose($myfile);
?>