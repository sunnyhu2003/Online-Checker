<!DOCTYPE html>
<html lang="zh-CN">
 <head> 
  <meta charset="utf-8" /> 
  <meta http-equiv="X-UA-Compatible" content="IE=edge" /> 
  <title>服务器在线状态监控</title> 
  <!-- 最新版本的 Bootstrap 核心 CSS 文件 --> 
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous" /> 
  <!-- 最新的 Bootstrap 核心 JavaScript 文件 --> 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> 
 </head>
 <body>
  <center>
   <h1>服务器在线状态监控</h1>
  </center>   
  <table class="table table-bordered"> 
   <tbody>
    <tr> 
    </tr>
   </tbody>
  </table>
  <table class="table"> 
   <thead> 
    <tr> 
     <th>#</th> 
     <th>服务器代号</th> 
     <th>服务器在线状态</th> 
    </tr> 
   </thead> 
   <tbody>
<?php
$myfile = fopen("data.txt", "r") or die("Unable to open file!");
$data = fread($myfile,filesize("data.txt"));
fclose($myfile);
$arr = (array) json_decode($data,true);
$t = 0;
while(!empty($arr[$t]['node'])){
	if($arr[$t]['icmp'] == 'true'){
  		echo'<tr class="success"> 
     	<th scope="row">'.$t.'</th> 
     	<td>'.$arr[$t]['node'].'</td> 
     	<td>'.$arr[$t]['icmp'].'</td> 
    	</tr> ';
  	}else{
      	echo'<tr class="danger"> 
     	<th scope="row">'.$t.'</th> 
     	<td>'.$arr[$t]['node'].'</td> 
     	<td>'.$arr[$t]['icmp'].'</td> 
    	</tr> ';
  	}
		$t=$t+1;
}
?>
   </tbody> 
  </table>    
 </body>
 <footer>
   <center>最后更新时间<?php $myfile = fopen("latest.txt", "r") or die("Unable to open file!");
$latest = fread($myfile,filesize("latest.txt"));
fclose($myfile);echo $latest;?></center>
 </footer>
</html>