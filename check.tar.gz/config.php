<?php
$ips = array(
	array("qn","154.81.3.22"),
	array("ncp","103.135.103.57"),
	array("cmi","134.122.129.65"),
  	array("txhk","119.28.130.131")
);
